package loon.template.mygame;

import loon.LTexture;
import loon.Screen;
import loon.Stage;
import loon.android.AndroidGame.AndroidSetting;
import loon.android.Loon;
import loon.canvas.LColor;
import loon.component.LTextArea;
import loon.events.Touched;

public class MainActivity extends Loon {

    public static class TestScreen extends Stage{

        @Override
        public void create(){
            // 构建一个300x240的游戏窗体背景图,颜色黑蓝相间,横向渐变
            LTexture texture = getGameWinFrame(300, 240, LColor.black, LColor.blue, false);
            // 允许显示行数默认(若显示行数设置可以写成(10,66,36,300,240)这类),位置66,36,大小300x240
            final LTextArea area = new LTextArea(66, 36, 300, 240);
            // 替换默认文字颜色并禁止文字闪烁
            area.setDefaultColor(255, 255, 255, false);
            area.setBackground(texture);
            area.put("你惊扰了【撒旦】的安眠", LColor.red);
            area.put("2333333333333", LColor.yellow);
            area.put("6666666666");
            area.put("点击我增加数据");
            // 从下向上刷数据
            // area.setShowType(LTextArea.TYPE_UP);
            // 清空数据
            // area.clear();
            area.up(new Touched() {

                @Override
                public void on(float x, float y) {
                    area.put("数据增加", LColor.red);

                }
            });
            // 偏移文字显示位置
            area.setLeftOffset(5);
            area.setTopOffset(5);
            // addString为在前一行追加数据
            area.addString("1", LColor.red);
            add(area);
        }

    }


    @Override
    public void onMain() {
        AndroidSetting setting = new AndroidSetting();
        setting.isFPS = true;
        setting.isMemory  = true;
        setting.isLogo = false;
        setting.fullscreen = true;
        setting.width = 480;
        setting.height = 320;
		//不允许配置文件改变屏幕方向
		setting.useOrientation = false;
        //若启动此模式，则画面等比压缩，不会失真
        setting.useRatioScaleFactor = false;
        //强制一个显示大小(在android模式下，不填则默认全屏，此模式可能会造成画面失真)
        //setting.width_zoom = getContainerWidth();
        //setting.height_zoom = getContainerHeight();
        //屏幕显示模式
        //setting.showMode = LMode.FitFill;
        setting.logoPath = "loon_logo.png";
        setting.fps = 60;
        setting.fontName = "Dialog";
        setting.appName = "test";
        setting.emulateTouch = false;
        setting.lockBackDestroy = false;
        register(setting, new Data() {

            @Override
            public Screen onScreen() {
                return new TestScreen();
            }
        });
    }
}
