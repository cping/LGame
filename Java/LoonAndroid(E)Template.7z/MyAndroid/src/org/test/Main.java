package org.test;

import loon.Screen;
import loon.android.Loon;
import loon.android.AndroidGame.AndroidSetting;
import loon.event.GameTouch;
import loon.opengl.GLEx;
import loon.utils.timer.LTimerContext;

public class Main extends Loon{
	
	public class ScreenTest extends Screen{

		@Override
		public void alter(LTimerContext arg0) {

			
		}

		@Override
		public void close() {
			
			
		}

		@Override
		public void draw(GLEx arg0) {
			
			
		}

		@Override
		public void onLoad() {
			
			
		}

		@Override
		public void pause() {
			
			
		}

		@Override
		public void resize(int arg0, int arg1) {
			
			
		}

		@Override
		public void resume() {
			
			
		}

		@Override
		public void touchDown(GameTouch arg0) {
			
			
		}

		@Override
		public void touchDrag(GameTouch arg0) {
			
			
		}

		@Override
		public void touchMove(GameTouch arg0) {
			
			
		}

		@Override
		public void touchUp(GameTouch arg0) {
			
			
		}
		
	}

	@Override
	public void onMain() {

		AndroidSetting setting = new AndroidSetting();
		setting.isFPS = true;
		setting.isLogo = false;
		setting.fullscreen = true;
		setting.width = 480;
		setting.height = 320;
		//若启动此模式，则画面等比压缩，不会失真
		setting.useRatioScaleFactor = false;
		//强制一个显示大小(在android模式下，不填则默认全屏，此模式可能会造成画面失真)
		//setting.width_zoom = getContainerWidth();
		//setting.height_zoom = getContainerHeight();
		//屏幕显示模式
		//setting.showMode = LMode.FitFill;
		setting.logoPath = "loon_logo.png";
		setting.fps = 60;
		setting.fontName = "Dialog";
		setting.appName = "test";
		register(setting, new Data() {

			@Override
			public Screen onScreen() {
				return new ScreenTest();
			}
		});
	
	}

}
