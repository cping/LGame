
package java.io;

public interface FileFilter {

	boolean accept(File file);

}
