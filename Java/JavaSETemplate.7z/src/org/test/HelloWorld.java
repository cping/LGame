package org.test;

import loon.LSetting;
import loon.LSystem;
import loon.LazyLoading;
import loon.Screen;
import loon.event.GameTouch;
import loon.font.IFont;
import loon.javase.Loon;
import loon.opengl.GLEx;
import loon.utils.timer.LTimerContext;

public class HelloWorld extends Screen {

	@Override
	public void alter(LTimerContext arg0) {

	}

	@Override
	public void close() {

	}

	@Override
	public void draw(GLEx g) {
		String text = "Hello World";
		IFont font = g.getFont();
		g.drawString(text, getHalfWidth() - font.stringWidth(text) / 2,
				getHalfHeight() - font.getHeight() / 2);
	}

	@Override
	public void onLoad() {

	}

	@Override
	public void pause() {

	}

	@Override
	public void resize(int arg0, int arg1) {

	}

	@Override
	public void resume() {

	}

	@Override
	public void touchDown(GameTouch arg0) {

	}

	@Override
	public void touchDrag(GameTouch arg0) {

	}

	@Override
	public void touchMove(GameTouch arg0) {

	}

	@Override
	public void touchUp(GameTouch arg0) {

	}

	public static void main(String[] args) {
		LSetting setting = new LSetting();
		setting.isFPS = true;
		setting.isLogo = false;
		setting.logoPath = "loon_logo.png";
		// 原始大小
		setting.width = 320;
		setting.height = 480;
		setting.fps = 60;
		setting.fontName = "黑体";
		setting.appName = "Hello";
		LSystem.NOT_MOVE = true;
		Loon.register(setting, new LazyLoading.Data() {

			@Override
			public Screen onScreen() {
				return new HelloWorld();
			}
		});
	}
}
